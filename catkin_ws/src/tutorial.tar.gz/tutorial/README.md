# Tutorial on ROS for COSC69/169 Multirobot systems

Sample code for showing publishers and subscribers, and services with two robots
in Stage. In particular, the robots will move randomly and stop in case they 
are too close to an obstacle.

## Getting Started

Create your catkin workspace in the folder of your choice and run: 

```
mkdir -p catkin_ws/src
cd catkin_ws/src
catkin_init_workspace

```

### Prerequisites

What things you need to install the software and how to install them

```
numpy

stage_ros
tf
geometry_msgs
std_srvs
nav_msgs
sensor_msgs
```

### Installing

```

Copy the `tutorial` folder and copy it in `src`.
Then build and source:

```
cd ..
catkin_make
```

## Run
For starting, e.g., robot_0, run each command in different windows 
(remember to always `source devel/setup.bash`):

```
roscore
rosrun stage_ros stageros $(rospack find tutorial)/world/maze.world
ROS_NAMESPACE=robot_0 rosrun tutorial random_cmd_node.py
ROS_NAMESPACE=robot_0 rosservice call start_stop "{}" # To start the robot moving.
ROS_NAMESPACE=robot_1 rosrun tutorial random_cmd_node.py
ROS_NAMESPACE=robot_1 rosservice call start_stop "{}" # To start the robot moving.
```

## Versioning

We use [SemVer](http://semver.org/) for versioning. For the versions available, see the [tags on this repository](https://github.com/your/project/tags). 

## Authors

* **Alberto Quattrini Li** 


## License

TODO.
